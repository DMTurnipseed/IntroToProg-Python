# ------------------------------------------------------------------------ #
# Title: Assignment 05
# Description: Working with Dictionaries and Files
#              When the program starts, load each "row" of data
#              in "ToDoList.txt" into a python Dictionary.
#              Add each dictionary "row" to a python list "table"
# ChangeLog (Who,When,What):
# DTurnipseed,08/08/2023,Created Script
#
# ------------------------------------------------------------------------ #

# -- Data -- #
# declare variables and constants
objFile = None # An object that represents a file
strFile = "ToDoList.txt" # data storage file
strData = ""   # A row of text data from the file
dicRow1 = {}    # A row of data separated into elements of a dictionary {Task,Priority}
lstTable = []  # A list that acts as a 'table' of rows
strMenu = ""   # A menu of user options
strChoice = "" # A Capture the user option selection


# -- Processing -- #
# Step 1 - When the program starts, load any data you have
# in a text file called ToDoList.txt into a python list of dictionaries rows (like Lab 5-2)

# Determines whether first line is "Task|Priority" and if not writes it to the file.
with open(strFile) as f:
    first_line = f.readline().strip('\n')
    if (first_line.lower() == "task|priority"):
        print("\n" + "This program lets you modify a list")
    else:
        objFile = open(strFile, "w")
        dicRow1 = {"Task":"Task", "Priority":"Priority"}
        objFile.write(dicRow1["Task"] + "|" + dicRow1["Priority"] + "\n")
        lstTable = [dicRow1]
        objFile = open(strFile, "r")
        for row in objFile:
            lstTable = row.split(",")
            print(lstTable[0])
        objFile.close()

# -- Input/Output -- #
# Step 2 - Display a menu of choices to the user
while (True):
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print()  # adding a new line for looks
    # Step 3 - Show the current items in the table
    if (strChoice.strip() == '1'):
        objFile = open(strFile, "r")
        print(objFile.read())
        continue
    # Step 4 - Add a new item to the list/Table
    elif (strChoice.strip() == '2'):
        objFile = open(strFile, "a")
        strTask = input("Add a task (ex: clean, groceries, etc): ")
        strPriority = input("Add a priority level (ex: 1-3 with 1 being top): ")
        dicRow2 = {"Task": strTask,"Priority": strPriority}
        objFile.write(dicRow2["Task"] + ',' + dicRow2["Priority"] + '\n')
        lstTable.append(dicRow2)
        objFile = open(strFile, "r")
        for row in objFile:
            print(row.strip())
        #objFile.close()
        continue
    # Step 5 - Remove a new item from the list/Table
    elif (strChoice.strip() == '3'):
        with open(strFile, "r+") as fp: # from https://pynative.com/python-delete-lines-from-file/
            # read an store all lines into list
            lines = fp.readlines()
            # move file pointer to the beginning of a file
            fp.seek(0)
            # truncate the file
            fp.truncate()
            # start writing lines except the last line
            # lines[:-1] from line 0 to the second last line
            fp.writelines(lines[:-1])
        # for row in objFile:
        #     print(row.strip())
            objFile.close()
        # print("Here is the list, which item would you like to remove?" + "\n")
        # strChoice = input("Enter task name to remove: ")
        # if strChoice in lstTable:
        continue
    # Step 6 - Save tasks to the ToDoList.txt file
    elif (strChoice.strip() == '4'):
        objFile = open(strFile, "r")
        print("File Saved")
        objFile.close()
        continue
    # Step 7 - Exit program
    elif (strChoice.strip() == '5'):
        print("Have a great day. Goodbye.")
        break  # and Exit the program